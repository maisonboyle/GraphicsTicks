javac -d ./out src/uk/ac/cam/cl/gfxintro/dab80/tick1/*.java

java -classpath ./out uk.ac.cam.cl.gfxintro.dab80.tick1.Tick1 --input tick1.xml --output output.png

(May need additional commands to get to java/javac directory?)